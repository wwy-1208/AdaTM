# layers/MTST_MoE_Encoder.py
import torch
import torch.nn as nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np
from typing import Optional, List
from einops import rearrange

# --- 依赖导入 ---
from layers.Embed import PositionalEmbedding
from layers.Long_encoder import S_Mamba_Expert
from torch.nn import TransformerEncoder, TransformerEncoderLayer

# --- 新的 MoELayer (专家调整版) ---
class MoELayerBranch(nn.Module):
    """
    适用于分支内部的 MoE 层。
    可以通过 config.ablation_mode 控制行为:
    - "moe": Transformer + S_Mamba (动态门控)
    - "transformer_only": 仅 Transformer
    - "s_mamba_only": 仅 S_Mamba
    - "sum_experts": Transformer 和 S_Mamba 输出直接相加
    """

    def __init__(self, config, device):
        super().__init__()
        self.config = config
        self.device = device
        self.d_model = config.d_model
        self.ablation_mode = getattr(config, 'ablation_mode', 'moe')

        print(f"[MoELayerBranch 初始化] d_model={self.d_model}, device={self.device}, 消融模式={self.ablation_mode}")

        # --- 条件性初始化 Transformer 专家 ---
        # 在 "moe", "transformer_only", "sum_experts" 模式下都需要 Transformer
        if self.ablation_mode in ["moe", "transformer_only", "sum_experts"]:
            num_heads = config.n_heads
            if self.d_model % num_heads != 0:
                valid_heads = [h for h in [8, 4, 2, 1] if self.d_model % h == 0]
                if not valid_heads: raise ValueError(f"无法为 d_model={self.d_model} 找到合适的 n_heads")
                num_heads = valid_heads[0]
                print(f"  已调整 Transformer 专家的 n_heads: {num_heads}")
            tf_encoder_layer = TransformerEncoderLayer(
                d_model=self.d_model, nhead=num_heads, dim_feedforward=config.d_ff,
                dropout=config.dropout, activation=config.activation, batch_first=True,
                device=device
            )
            self.transformer_expert = TransformerEncoder(
                tf_encoder_layer, num_layers=1,
                norm=nn.LayerNorm(self.d_model, device=device)
            ).to(device)
            print(f"  Transformer 专家已初始化 (用于模式: {self.ablation_mode}, {num_heads} 个头)")

        # --- 条件性初始化 S_Mamba 专家 ---
        # 在 "moe", "s_mamba_only", "sum_experts" 模式下都需要 S_Mamba
        if self.ablation_mode in ["moe", "s_mamba_only", "sum_experts"]:
            class TempConfigAdaTM: # 使用与之前一致的临时配置对象名
                pass
            s_mamba_config_expert = TempConfigAdaTM()
            for k, v in vars(config).items(): setattr(s_mamba_config_expert, k, v)
            s_mamba_config_expert.e_layers = 1
            self.s_mamba_expert = S_Mamba_Expert(s_mamba_config_expert).to(device)
            print(f"  S_Mamba 专家已初始化 (用于模式: {self.ablation_mode})")

        # --- 条件性初始化门控网络 (仅在 "moe" 模式下需要) ---
        if self.ablation_mode == "moe":
            self.gate = nn.Linear(self.d_model, 2, bias=False).to(device) # 假设有2个专家
            print("  门控网络已初始化 (MoE 模式)")
        else:
            self.gate = None

    def forward(self, x: Tensor, pos_emb: Optional[Tensor] = None) -> Tensor:
        B_N, P, C = x.shape

        # --- 根据消融模式选择执行路径 ---
        if self.ablation_mode == "transformer_only":
            if not hasattr(self, 'transformer_expert'):
                raise RuntimeError("消融模式为 'transformer_only'，但 Transformer 专家未初始化。")
            tf_input = x
            if pos_emb is not None:
                if pos_emb.shape[0] == 1 and pos_emb.shape[1] == P:
                    tf_input = tf_input + pos_emb
                elif pos_emb.shape[0] == P and pos_emb.shape[1] == 1:
                    tf_input = tf_input + pos_emb.squeeze(1).unsqueeze(0)
                elif pos_emb.shape == tf_input.shape: # 新增判断，如果形状完全一致直接相加
                    tf_input = tf_input + pos_emb
                else:
                    print(f"警告 (transformer_only模式): Transformer 位置编码形状 {pos_emb.shape} 无法广播到输入 {tf_input.shape}。")
            return self.transformer_expert(tf_input)

        elif self.ablation_mode == "s_mamba_only":
            if not hasattr(self, 's_mamba_expert'):
                raise RuntimeError("消融模式为 's_mamba_only'，但 S_Mamba 专家未初始化。")
            return self.s_mamba_expert(x)

        elif self.ablation_mode == "sum_experts": # 新增的消融模式
            if not hasattr(self, 'transformer_expert') or not hasattr(self, 's_mamba_expert'):
                raise RuntimeError("消融模式为 'sum_experts'，但必要的专家组件未初始化。")

            # --- 计算 Transformer 专家输出 ---
            tf_input_sum = x
            if pos_emb is not None:
                if pos_emb.shape[0] == 1 and pos_emb.shape[1] == P:
                    tf_input_sum = tf_input_sum + pos_emb
                elif pos_emb.shape[0] == P and pos_emb.shape[1] == 1:
                    tf_input_sum = tf_input_sum + pos_emb.squeeze(1).unsqueeze(0)
                elif pos_emb.shape == tf_input_sum.shape: # 新增判断
                    tf_input_sum = tf_input_sum + pos_emb
                else:
                    print(f"警告 (sum_experts模式): Transformer 位置编码形状 {pos_emb.shape} 无法广播到输入 {tf_input_sum.shape}。")
            tf_output = self.transformer_expert(tf_input_sum)

            # --- 计算 S_Mamba 专家输出 ---
            mamba_output = self.s_mamba_expert(x)

            # --- 直接相加专家输出 ---
            return tf_output + mamba_output

        elif self.ablation_mode == "moe":
            if not hasattr(self, 'transformer_expert') or not hasattr(self, 's_mamba_expert') or self.gate is None:
                raise RuntimeError("消融模式为 'moe'，但必要的组件（专家或门控）未初始化。")

            context = x[:, 0, :]
            gate_logits = self.gate(context)
            gate_weights = F.softmax(gate_logits, dim=-1)

            tf_input_moe = x
            if pos_emb is not None:
                if pos_emb.shape[0] == 1 and pos_emb.shape[1] == P:
                    tf_input_moe = tf_input_moe + pos_emb
                elif pos_emb.shape[0] == P and pos_emb.shape[1] == 1:
                    tf_input_moe = tf_input_moe + pos_emb.squeeze(1).unsqueeze(0)
                elif pos_emb.shape == tf_input_moe.shape: # 新增判断
                    tf_input_moe = tf_input_moe + pos_emb
                else:
                    print(f"警告 (MoE模式): Transformer 位置编码形状 {pos_emb.shape} 无法广播到输入 {tf_input_moe.shape}。")
            tf_output = self.transformer_expert(tf_input_moe)
            mamba_output = self.s_mamba_expert(x)

            g_trans = gate_weights[:, 0].unsqueeze(1).unsqueeze(2)
            g_mamba = gate_weights[:, 1].unsqueeze(1).unsqueeze(2)
            weighted_output = g_trans * tf_output + g_mamba * mamba_output # [cite: 321]
            return weighted_output
        else:
            raise ValueError(f"未知的消融模式: {self.ablation_mode}")

# --- 修改 BranchEncoder ---
class BranchEncoder(nn.Module):
    def __init__(self, config, patch_len, stride, q_len, device):
        super().__init__()
        # ... (保留 config, patch_len, stride, q_len, d_model, n_layers, device) ...
        self.config = config
        self.patch_len = patch_len
        self.stride = stride
        self.q_len = q_len
        self.d_model = config.d_model
        self.n_layers = config.e_layers
        self.device = device
        self.padding_patch = config.padding_patch

        if self.padding_patch == 'end':
            # Padding on time dimension (last dim of [B, N, L])
            self.padding_layer = nn.ReplicationPad1d((0, self.stride))

        # Patch Projection (作用在 patch_len 维度)
        self.projection = nn.Linear(self.patch_len, self.d_model).to(device)

        # Positional Encoding (长度 q_len)
        self.pos_embed = PositionalEmbedding(self.d_model, max_len=self.q_len).to(device) # 或可学习 PE

        # MoE Layers + FF (保持不变)
        self.layers = nn.ModuleList()
        for _ in range(self.n_layers):
             moe_block = MoELayerBranch(config, device=device)
             ff_block = nn.Sequential(
                 nn.Linear(self.d_model, config.d_ff),
                 nn.GELU() if config.activation == 'gelu' else nn.ReLU(),
                 nn.Dropout(config.dropout),
                 nn.Linear(config.d_ff, self.d_model),
                 nn.Dropout(config.dropout)
             ).to(device)
             norm1 = nn.LayerNorm(self.d_model).to(device)
             norm2 = nn.LayerNorm(self.d_model).to(device)
             self.layers.append(nn.ModuleList([norm1, moe_block, norm2, ff_block]))

    def forward(self, x_branch):
        # x_branch: [B, N, L] (N=C_in, L=seq_len)
        B, N, L = x_branch.shape

        # 1. Padding (if needed)
        if self.padding_patch == 'end':
            # Pad the L dimension
            # Need to reshape for Conv1d padding: [B*N, 1, L] or [B*N, L]?
            # ReplicationPad1d expects [B, C, L] or [C, L]
            # Reshape to [B*N, 1, L] might work, or pad manually / use F.pad
            # Using F.pad for simplicity: pads the last dimension
            x_padded = F.pad(x_branch, (0, self.stride), mode='replicate') # [B, N, L_padded]
        else:
            x_padded = x_branch

        # 2. Patching (Unfold on L dimension)
        # unfold output [B, N, num_patches, patch_len]
        patches = x_padded.unfold(dimension=-1, size=self.patch_len, step=self.stride)
        if patches.shape[2] != self.q_len: # Check patch count
             print(f"警告: BranchEncoder patch 数量 ({patches.shape[2]}) 与预期 q_len ({self.q_len}) 不匹配。")
             # Handle mismatch (e.g., truncate/pad - simple truncation here)
             patches = patches[:, :, :self.q_len, :]
             if patches.shape[2] != self.q_len: raise ValueError("输入序列过短。")

        # 3. Projection
        # Input [B, N, q_len, patch_len] -> Output [B, N, q_len, d_model]
        projected_patches = self.projection(patches)

        # 4. Reshape for MoE Layers
        # Output [B*N, q_len, d_model]
        u = rearrange(projected_patches, 'b n p d -> (b n) p d')

        # 5. Apply MoE + FF Layers
        pos_emb_val = self.pos_embed(u) # Get PE of length q_len
        for norm1, moe_block, norm2, ff_block in self.layers:
            res_moe = u
            u_norm1 = norm1(u)
            moe_out = moe_block(u_norm1, pos_emb=pos_emb_val)
            u = res_moe + moe_out
            res_ff = u
            u_norm2 = norm2(u)
            ff_out = ff_block(u_norm2)
            u = res_ff + ff_out

        # 6. Reshape back to [B, N, q_len, d_model]
        output = rearrange(u, '(b n) p d -> b n p d', b=B)

        # 7. Permute to [B, N, d_model, q_len] for flattening in MultiBranchMoEEncoder
        output = output.permute(0, 1, 3, 2)

        return output # [B, N, d_model, q_len]


class MultiBranchMoEEncoder(nn.Module):
    """管理多个并行 BranchEncoder 的模块"""
    def __init__(self, config, device):
        super().__init__()
        self.config = config
        self.device = device
        self.n_branches = config.n_branches
        self.d_model = config.d_model

        # 解析多分支参数
        self.patch_len_ls = [int(p) for p in config.patch_len_ls.split(',')]
        self.stride_ls = [int(s) for s in config.stride_ls.split(',')]
        assert len(self.patch_len_ls) == self.n_branches
        assert len(self.stride_ls) == self.n_branches

        self.patch_nums = [] # 每个分支的 patch 数量
        for i in range(self.n_branches):
            # q_len calculation (与 BranchEncoder 内部一致)
            L = config.seq_len
            P = self.patch_len_ls[i]
            S = self.stride_ls[i]
            if config.padding_patch == 'end':
                # 计算填充后的长度 L_padded
                L_padded = L + S # 简化假设，严格应为 L + (S - (L-P)%S)%S if (L-P)%S!=0 else L
                q_len = int((L_padded - P) / S + 1)
            else:
                q_len = int((L - P) / S + 1)
            self.patch_nums.append(q_len)

        print(f"[MultiBranchMoEEncoder] 初始化: {self.n_branches} 个分支")
        print(f"  - Patch Lens: {self.patch_len_ls}")
        print(f"  - Strides: {self.stride_ls}")
        print(f"  - Patch Nums: {self.patch_nums}")

        # 创建分支
        self.branches = nn.ModuleList([
            BranchEncoder(
                config=config,
                patch_len=self.patch_len_ls[j],
                stride=self.stride_ls[j],
                q_len=self.patch_nums[j],
                device=device
            ) for j in range(self.n_branches)
        ])

        # 计算拼接后的总特征维度 (用于 Prediction Head)
        # 每个分支输出 [B, N, D, P_j] -> flatten 为 [B, N, D * P_j]
        self.total_feature_dim = self.d_model * sum(self.patch_nums)
        print(f"  - Total Flattened Dim per Variable: {self.total_feature_dim}")

    def forward(self, x: Tensor) -> Tensor:
        # x shape: [B, N, L] (N=C_in, L=seq_len)
        branch_outputs_flattened = []

        for j in range(self.n_branches):
            # branch_out shape: [B, N, D, P_j]
            branch_out = self.branches[j](x)
            # Flatten D and P_j: [B, N, D * P_j]
            branch_flat = rearrange(branch_out, 'b n d p -> b n (d p)')
            branch_outputs_flattened.append(branch_flat)

        # Concatenate along the feature dimension (last dim)
        # combined_features shape: [B, N, total_feature_dim]
        combined_features = torch.cat(branch_outputs_flattened, dim=-1)

        return combined_features # [B, N, total_feature_dim]
