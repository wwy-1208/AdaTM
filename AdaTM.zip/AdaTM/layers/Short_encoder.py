# Cell
from typing import Callable, Optional
import torch
from torch import nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np

from layers.LWT_layers import *
from layers.RevIN import RevIN

# Cell
class Short_encoder(nn.Module):
    def __init__(self, c_in, context_window, local_ws, patch_len, stride, config):
        super().__init__()
        self.context_window = context_window
        self.patch_len = patch_len # 假设这里是子补丁长度，例如 1 或 4
        self.stride = stride     # 假设这里是子补丁步长，例如 1 或 4

        # 计算预期的 patch_num，但这基于 context_window，可能不适用于实际输入 P
        # self.expected_patch_num = int((context_window - patch_len) / stride + 1)
        # TSTiEncoder 初始化时需要 patch_num，这是一个问题点

        # --- 关键：初始化 TSTiEncoder 时 patch_num 可能需要设为最大可能值或 context_window ---
        # 假设我们有一个方法获取 TSTiEncoder 期望的长度 q_len
        # 例如，直接使用 context_window 作为最大可能的序列长度
        # 或者基于 context_window, patch_len, stride 计算一个固定的 patch_num
        self.init_patch_num = int((context_window - patch_len) / stride + 1) if stride > 0 else context_window // patch_len # 需要健壮的计算

        self.backbone = TSTiEncoder(
            context_window=context_window,  # 这个参数可能不需要传递给 TSTiEncoder
            c_in=c_in,  # = config.d_model
            local_ws=local_ws,  # = config.local_ws
            patch_num=self.init_patch_num,  # 使用基于 context_window 计算的值
            patch_len=self.patch_len,  # 使用子补丁长度
            # --- 从 config 传递 ---
            n_layers=config.e_layers,  # 使用 config.e_layers (el3)
            d_model=config.d_model,  # 使用 config.d_model (dm16)
            n_heads=config.n_heads,  # 使用 config.n_heads (nh2)
            d_ff=config.d_ff,  # 使用 config.d_ff (df64)
            attn_dropout=config.dropout,  # 假设 attn_dropout 和 dropout 相同
            dropout=config.dropout,  # 使用 config.dropout (dl1?)
            act=config.activation,  # 传递激活函数名称
            # 其他 TSTiEncoder 需要的参数，如果 config 中有的话
            # 例如 pre_norm, res_attention 等
        )

    def forward(self, z):
        B_N, P, C = z.shape
        # ... 检查 stride/patch_len, 如果 P < self.patch_len 则填充 ...
        # Unfold (dimension=1)
        z = z.unfold(dimension=1, size=self.patch_len, step=self.stride)
        # z 形状: [B*N, current_patch_num, C, self.patch_len]
        # 为 TSTiEncoder 调整维度: [B*N, C, self.patch_len, current_patch_num]
        z = z.permute(0, 2, 3, 1)
        # 这里不进行填充/截断
        z = self.backbone(z) # Backbone 现在内部处理动态长度
        # ... 最终的 permute ...
        return z


class TSTiEncoder(nn.Module):  #i means channel-independent
    def __init__(self, context_window, c_in, local_ws, patch_num, patch_len, max_seq_len=1024,
                 n_layers=3, d_model=16, n_heads=16, d_k=None, d_v=None,
                 d_ff=256, norm='BatchNorm', attn_dropout=0., dropout=0., act="gelu", store_attn=False,
                 key_padding_mask='auto', padding_var=None, attn_mask=None, res_attention=True, pre_norm=False,
                 pe='zeros', learn_pe=True, verbose=False, **kwargs):

        super().__init__()
        #print(f"[TSTiEncoder Init Debug] Received patch_len: {patch_len}")
        #print(f"[TSTiEncoder Init Debug] Received d_model: {d_model}")
        #print(f"[TSTiEncoder Init Debug] Received n_heads: {n_heads}")
        self.patch_num = patch_num
        self.patch_len = patch_len

        # Input encoding
        W_inp_len = patch_len
        self.W_P = nn.Linear(W_inp_len, d_model)
        #print(f"[TSTiEncoder Init Debug] W_P input dim (W_inp_len): {W_inp_len}")# Eq 1: projection of feature vectors onto a d-dim vector space
        q_len = patch_num

        # q_len = patch_num
        # self.seq_len = q_len

        # Positional encoding
        self.W_pos = positional_encoding(pe, learn_pe, q_len, d_model)

        # Residual dropout
        self.dropout = nn.Dropout(dropout)

        # Encoder
        self.encoder = TSTEncoder(q_len, d_model, n_heads, d_k=d_k, d_v=d_v, d_ff=d_ff, local_ws=local_ws, norm=norm, attn_dropout=attn_dropout, dropout=dropout,
                                   pre_norm=pre_norm, activation=act, res_attention=res_attention, n_layers=n_layers, store_attn=store_attn)

    def forward(self, x) -> Tensor:
        #print(f"[TSTiEncoder 入口] x 形状: {x.shape}")  # 打印刚传入的 x 形状
        n_vars = x.shape[1]
        x = x.permute(0, 1, 3, 2)
        #print(f"[TSTiEncoder permute后] x 形状: {x.shape}")  # 打印 permute后的 x 形状
        x = self.W_P(x)
        #print(f"[TSTiEncoder W_P后] x 形状: {x.shape}")  # 打印 W_P 作用后的 x 形状 (!!! 关键 !!!)

        # --- 接下来的代码基于上面打印出的 W_P后 x 的形状来推导 ---
        bs_times_nvars = x.shape[0] * x.shape[1]
        actual_patch_num = x.shape[2]  # <-- 这里的值应该来自 W_P 作用后的 x.shape[2]
        d_model = x.shape[3]  # <-- 这里的值应该来自 W_P 作用后的 x.shape[3]
        target_u_shape = (bs_times_nvars, actual_patch_num, d_model)
        #print(f"[TSTiEncoder reshape 前计算] actual_patch_num: {actual_patch_num}")
        #print(f"[TSTiEncoder reshape 前计算] d_model: {d_model}")
        #print(f"[TSTiEncoder reshape 前计算] 目标 u 形状: {target_u_shape}")

        u = torch.reshape(x, target_u_shape)
        #print(f"[TSTiEncoder reshape 后] u 形状: {u.shape}")
        # --- reshape 操作结束 ---

        #print(f"[TSTiEncoder reshape 后] u 形状: {u.shape}")  # 打印 reshape 后的实际形状

        # --- 动态 W_pos 调整 ---
        if hasattr(self, 'W_pos'):
            #print(f"[W_pos 调整前] W_pos 形状: {self.W_pos.shape}")
            #print(f"[W_pos 调整前] actual_patch_num: {actual_patch_num}")  # <--- 确认这里的 actual_patch_num 是多少
            if self.W_pos.shape[-2] != actual_patch_num:
                if self.W_pos.shape[-2] > actual_patch_num:
                    adjusted_W_pos = self.W_pos.narrow(-2, 0, actual_patch_num)
                else:
                    pad_width = actual_patch_num - self.W_pos.shape[-2]
                    # ... padding code ...
            else:
                adjusted_W_pos = self.W_pos
            #print(f"[W_pos 调整后] adjusted_W_pos 形状: {adjusted_W_pos.shape}")  # <--- 确认调整后的形状
            u = self.dropout(u + adjusted_W_pos)
        else:  # 如果没有 W_pos (例如 pe='zeros' 且 learn_pe=False)
            u = self.dropout(u)
        # --- 调整结束 ---

        z = self.encoder(u)  # 传递具有正确长度的 u
        # ... (reshape 和 permute z) ...
        return z



# Cell
class TSTEncoder(nn.Module):
    def __init__(self, q_len, d_model, n_heads, d_k=None, d_v=None, d_ff=None, local_ws=None,
                        norm='BatchNorm', attn_dropout=0., dropout=0., activation='gelu',
                        res_attention=False, n_layers=1, pre_norm=False, store_attn=False):
        super().__init__()

        self.layers = nn.ModuleList([TSTEncoderLayer(q_len, d_model, n_heads=n_heads, d_k=d_k, d_v=d_v, d_ff=d_ff, local_ws=local_ws, norm=norm,
                                                      attn_dropout=attn_dropout, dropout=dropout,
                                                      activation=activation, res_attention=res_attention,
                                                      pre_norm=pre_norm, store_attn=store_attn) for i in range(n_layers)])
        self.res_attention = res_attention

    def forward(self, src:Tensor, key_padding_mask:Optional[Tensor]=None, attn_mask:Optional[Tensor]=None):
        output = src
        scores = None
        if self.res_attention:
            for mod in self.layers: output, scores = mod(output, prev=scores, key_padding_mask=key_padding_mask, attn_mask=attn_mask)
            return output
        else:
            for mod in self.layers: output = mod(output, key_padding_mask=key_padding_mask, attn_mask=attn_mask)
            return output



class TSTEncoderLayer(nn.Module):
    def __init__(self, q_len, d_model, n_heads, d_k=None, d_v=None, d_ff=64, local_ws=None, store_attn=False,
                 norm='BatchNorm', attn_dropout=0, dropout=0., bias=True, activation="gelu", res_attention=False, pre_norm=False):
        super().__init__()
        assert not d_model%n_heads, f"d_model ({d_model}) must be divisible by n_heads ({n_heads})"
        d_k = d_model // n_heads if d_k is None else d_k
        d_v = d_model // n_heads if d_v is None else d_v

        # Multi-Head attention
        self.res_attention = res_attention
        self.self_attn = _MultiheadAttention(d_model, n_heads, d_k, d_v, local_ws=local_ws, attn_dropout=attn_dropout, proj_dropout=dropout, res_attention=res_attention)

        # Add & Norm
        self.dropout_attn = nn.Dropout(dropout)
        if "batch" in norm.lower():
            self.norm_attn = nn.Sequential(Transpose(1,2), nn.BatchNorm1d(d_model), Transpose(1,2))
        else:
            self.norm_attn = nn.LayerNorm(d_model)

        # Position-wise Feed-Forward
        self.ff = nn.Sequential(nn.Linear(d_model, d_ff, bias=bias),
                                get_activation_fn(activation),
                                nn.Dropout(dropout),
                                nn.Linear(d_ff, d_model, bias=bias))

        # Add & Norm
        self.dropout_ffn = nn.Dropout(dropout)
        if "batch" in norm.lower():
            self.norm_ffn = nn.Sequential(Transpose(1,2), nn.BatchNorm1d(d_model), Transpose(1,2))
        else:
            self.norm_ffn = nn.LayerNorm(d_model)

        self.pre_norm = pre_norm
        self.store_attn = store_attn


    def forward(self, src:Tensor, prev:Optional[Tensor]=None, key_padding_mask:Optional[Tensor]=None, attn_mask:Optional[Tensor]=None) -> Tensor:
        # Multi-Head attention sublayer
        if self.pre_norm:
            src = self.norm_attn(src)
        ## Multi-Head attention
        if self.res_attention:
            src2, attn, scores = self.self_attn(src, src, src, prev, key_padding_mask=key_padding_mask, attn_mask=attn_mask)
        else:
            src2, attn = self.self_attn(src, src, src, key_padding_mask=key_padding_mask, attn_mask=attn_mask)
        if self.store_attn:
            self.attn = attn
        ## Add & Norm
        src = src + self.dropout_attn(src2) # Add: residual connection with residual dropout
        if not self.pre_norm:
            src = self.norm_attn(src)

        # Feed-forward sublayer
        if self.pre_norm:
            src = self.norm_ffn(src)
        ## Position-wise Feed-Forward
        src2 = self.ff(src)
        ## Add & Norm
        src = src + self.dropout_ffn(src2) # Add: residual connection with residual dropout
        if not self.pre_norm:
            src = self.norm_ffn(src)

        if self.res_attention:
            return src, scores
        else:
            return src




class _MultiheadAttention(nn.Module):
    def __init__(self, d_model, n_heads, d_k=None, d_v=None, local_ws=None, res_attention=False, attn_dropout=0., proj_dropout=0., qkv_bias=True, lsa=False):
        """Multi Head Attention Layer
        Input shape:
            Q:       [batch_size (bs) x max_q_len x d_model]
            K, V:    [batch_size (bs) x q_len x d_model]
            mask:    [q_len x q_len]
        """
        super().__init__()
        d_k = d_model // n_heads if d_k is None else d_k
        d_v = d_model // n_heads if d_v is None else d_v

        self.n_heads, self.d_k, self.d_v = n_heads, d_k, d_v

        self.W_Q = nn.Linear(d_model, d_k * n_heads, bias=qkv_bias)
        self.W_K = nn.Linear(d_model, d_k * n_heads, bias=qkv_bias)
        self.W_V = nn.Linear(d_model, d_v * n_heads, bias=qkv_bias)

        # Scaled Dot-Product Attention (multiple heads)
        self.res_attention = res_attention
        self.sdp_attn = _ScaledDotProductAttention(d_model, n_heads, local_ws=local_ws, attn_dropout=attn_dropout, res_attention=self.res_attention, lsa=lsa)

        # Poject output
        self.to_out = nn.Sequential(nn.Linear(n_heads * d_v, d_model), nn.Dropout(proj_dropout))


    def forward(self, Q:Tensor, K:Optional[Tensor]=None, V:Optional[Tensor]=None, prev:Optional[Tensor]=None,
                key_padding_mask:Optional[Tensor]=None, attn_mask:Optional[Tensor]=None):
        bs = Q.size(0)
        if K is None: K = Q
        if V is None: V = Q

        # Linear (+ split in multiple heads)
        q_s = self.W_Q(Q).view(bs, -1, self.n_heads, self.d_k).transpose(1,2)       # q_s    : [bs x n_heads x max_q_len x d_k]
        k_s = self.W_K(K).view(bs, -1, self.n_heads, self.d_k).permute(0,2,3,1)     # k_s    : [bs x n_heads x d_k x q_len] - transpose(1,2) + transpose(2,3)
        v_s = self.W_V(V).view(bs, -1, self.n_heads, self.d_v).transpose(1,2)       # v_s    : [bs x n_heads x q_len x d_v]

        # Apply Scaled Dot-Product Attention (multiple heads)
        if self.res_attention:
            output, attn_weights, attn_scores = self.sdp_attn(q_s, k_s, v_s, prev=prev, key_padding_mask=key_padding_mask, attn_mask=attn_mask)
        else:
            output, attn_weights = self.sdp_attn(q_s, k_s, v_s, key_padding_mask=key_padding_mask, attn_mask=attn_mask)
        # output: [bs x n_heads x q_len x d_v], attn: [bs x n_heads x q_len x q_len], scores: [bs x n_heads x max_q_len x q_len]

        # back to the original inputs dimensions
        output = output.transpose(1, 2).contiguous().view(bs, -1, self.n_heads * self.d_v) # output: [bs x q_len x n_heads * d_v]
        output = self.to_out(output)

        if self.res_attention: return output, attn_weights, attn_scores
        else: return output, attn_weights


class _ScaledDotProductAttention(nn.Module):
    r"""Scaled Dot-Product Attention module (Attention is all you need by Vaswani et al., 2017) with optional residual attention from previous layer
    (Realformer: Transformer likes residual attention by He et al, 2020) and locality self sttention (Vision Transformer for Small-Size Datasets
    by Lee et al, 2021)"""

    def __init__(self, d_model, n_heads, local_ws=None, attn_dropout=0., res_attention=False, lsa=False):
        super().__init__()
        self.attn_dropout = nn.Dropout(attn_dropout)
        self.res_attention = res_attention
        head_dim = d_model // n_heads
        self.scale = nn.Parameter(torch.tensor(head_dim ** -0.5), requires_grad=lsa)
        self.lsa = lsa
        self.local_ws = local_ws

    def forward(self, q:Tensor, k:Tensor, v:Tensor, prev:Optional[Tensor]=None, key_padding_mask:Optional[Tensor]=None, attn_mask:Optional[Tensor]=None):
        '''
        Input shape:
            q               : [bs x n_heads x max_q_len x d_k]
            k               : [bs x n_heads x d_k x seq_len]
            v               : [bs x n_heads x seq_len x d_v]
            prev            : [bs x n_heads x q_len x seq_len]
            key_padding_mask: [bs x seq_len]
            attn_mask       : [1 x seq_len x seq_len]
        Output shape:
            output:  [bs x n_heads x q_len x d_v]
            attn   : [bs x n_heads x q_len x seq_len]
            scores : [bs x n_heads x q_len x seq_len]
        '''

        # Scaled MatMul (q, k) - similarity scores for all pairs of positions in an input sequence
        attn_scores = torch.matmul(q, k) * self.scale      # attn_scores : [bs x n_heads x max_q_len x q_len]

        # Add pre-softmax attention scores from the previous layer (optional)
        if prev is not None: attn_scores = attn_scores + prev
        # Add Local Attntion
        local_mask = self.get_local_mask(q.shape[2], self.local_ws).to(q.device)
        # 反转掩码：掩盖窗口 *外部* 的位置
        attn_scores.masked_fill_(~local_mask, -np.inf)  # 注意取反符号 ~

        # Attention mask (optional)
        if attn_mask is not None:                                     # attn_mask with shape [q_len x seq_len] - only used when q_len == seq_len
            if attn_mask.dtype == torch.bool:
                attn_scores.masked_fill_(attn_mask, -np.inf)
            else:
                attn_scores += attn_mask

        # Key padding mask (optional)
        if key_padding_mask is not None:                              # mask with shape [bs x q_len] (only when max_w_len == q_len)
            attn_scores.masked_fill_(key_padding_mask.unsqueeze(1).unsqueeze(2), -np.inf)

        # normalize the attention weights
        attn_weights = F.softmax(attn_scores, dim=-1)                 # attn_weights   : [bs x n_heads x max_q_len x q_len]
        attn_weights = self.attn_dropout(attn_weights)

        # compute the new values given the attention weights
        output = torch.matmul(attn_weights, v)                        # output: [bs x n_heads x max_q_len x d_v]

        if self.res_attention: return output, attn_weights, attn_scores
        else: return output, attn_weights


    def get_local_mask(self, attn_size: int, window_size: int, p=1.0):
        # Check if window size is odd
        assert window_size % 2 == 1, "The window size is assumed to be odd (counts self-attention + 2 wings)"
        h_win_size = window_size // 2 + 1

        # Generate grid for the 1D pattern
        coords = torch.arange(attn_size)
        grid = torch.meshgrid(coords, indexing='ij')
        grid_flat = grid[0].flatten().float()

        # Calculate distances using the cdist function
        d = torch.cdist(grid_flat.unsqueeze(1), grid_flat.unsqueeze(1), p=p)

        # Generate the local pattern mask based on the half window size
        mask = d < h_win_size

        return mask