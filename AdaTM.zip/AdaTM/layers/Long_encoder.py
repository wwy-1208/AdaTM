import torch
import torch.nn as nn
from layers.Mamba_EnDec import Encoder, EncoderLayer
from mamba_ssm import Mamba
# 假设S_mamba中的Model类已正确导入，这里仅为示例
from layers.Embed import DataEmbedding_inverted
from typing import Optional, Tuple
# 定义S_mamba_Encoder类
#class S_mamba_Encoder(nn.Module):
    #def __init__(self, d_model, m_layers, d_ff, dropout, act, d_state, d_conv):
        #super().__init__()
        # 不再需要 W_P 层，输入已经是 d_model 维度
        #self.m_layers = m_layers
        #self.s_mamba_layers = nn.ModuleList([
            #S_mamba_Encoder_Layer(d_model, d_ff, dropout, act, d_state, d_conv)
            #for _ in range(m_layers)
        #])

    #def forward(self, x):
        # x 的输入维度应为 [B, num_patches, d_model, C]
        #for layer in self.s_mamba_layers:
            #x = layer(x)
        #return x

# 定义S_mamba_Encoder_Layer类，实现S_mamba的核心逻辑
#class S_mamba_Encoder_Layer(nn.Module):
    #def __init__(self, d_model, d_ff, dropout, act, d_state, d_conv):
        #super().__init__()
        #self.encoder_layer = EncoderLayer(
            #Mamba(
                #d_model=d_model,
                #d_state=d_state,
                #d_conv=d_conv
            #),
            #Mamba(
                #d_model=d_model,
                #d_state=d_state,
                #d_conv=d_conv
            #),
            #d_model,
            #d_ff,
            #dropout=dropout,
            #activation=act
        #)

    #def forward(self, x):
        ## 调用S_mamba的EncoderLayer实现核心计算逻辑
        #x, _ = self.encoder_layer(x)
        #return x

# 修改Long_encoder类
#class Long_encoder(nn.Module):
    #def __init__(self, c_in:int, long_context_window:int, target_window:int, m_patch_len:int, m_stride:int,
                 #m_layers:int=3, d_model=128,
                 #d_ff:int=256, norm:str='BatchNorm', dropout:float=0., act:str="gelu",
                 #pre_norm:bool=False,
                 #d_state:int=16, d_conv:int=4,
                 #fc_dropout:float=0., head_dropout = 0, padding_patch = None,
                 #pretrain_head:bool=False, head_type = 'flatten', individual = False, revin = True, affine = True, subtract_last = False,
                 #verbose:bool=False, **kwargs):

        #super().__init__()
        # Patching
        #self.m_patch_len = m_patch_len
        #self.m_stride = m_stride
        #self.padding_patch = padding_patch
        #m_patch_num = int((long_context_window - m_patch_len) / m_stride + 1)
        #if padding_patch == 'end':
            #self.padding_patch_layer = nn.ReplicationPad1d((0, m_stride))
            #m_patch_num += 1
        # Backbone
        #self.backbone = S_Mamba_Encoder(c_in, m_layers, d_model, d_ff, dropout, act, d_state, d_conv, m_patch_len)

    #def forward(self, z):
        #if self.padding_patch == 'end':
            #z = self.padding_patch_layer(z)
        #z = z.unfold(dimension=-1, size=self.m_patch_len, step=self.m_stride)
        #z = z.permute(0, 1, 3, 2)
        #z = self.backbone(z)
        #return z



# S_Mamba_Encoder 作为 Mamba 专家模块
class S_Mamba_Expert(nn.Module):
    """
    封装 S_Mamba 的 Encoder 作为 MoE 中的一个专家。
    输入输出形状: [Batch*N, SeqLen, Dim]
    """
    def __init__(self, configs):
        super().__init__()
        self.d_model = configs.d_model
        # 注意：这里的 EncoderLayer 和 Encoder 来自 layers.Mamba_EnDec
        self.encoder = Encoder(
            [
                EncoderLayer(
                    Mamba(
                        d_model=configs.d_model,
                        d_state=configs.d_state,
                        d_conv=configs.d_conv, # 使用 d_conv
                        expand=1, # 假设 expand=1
                    ),
                    Mamba( # 第二个 Mamba 实例
                        d_model=configs.d_model,
                        d_state=configs.d_state,
                        d_conv=configs.d_conv,
                        expand=1,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation
                ) for _ in range(configs.e_layers) # Mamba 专家内部也可能有多个 Mamba 层
            ],
            norm_layer=torch.nn.LayerNorm(configs.d_model) if getattr(configs, 'norm_layer', True) else None
        )
        print(f"[S_Mamba_Expert] 初始化完成, 内部层数: {configs.e_layers}")

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Args:
            x (torch.Tensor): 输入序列, 形状 [B*N, P, D]
        Returns:
            torch.Tensor: 输出序列, 形状 [B*N, P, D]
        """
        encoder_output, _ = self.encoder(x, attn_mask=mask)
        return encoder_output