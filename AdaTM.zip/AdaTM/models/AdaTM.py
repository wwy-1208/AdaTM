# coding=utf-8

from layers.Embed import PositionalEmbedding
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional
from layers.MTST_Backbone import Flatten_Head # 复用 MTST 的 Head 或使用
# --- 依赖导入 ---
from layers.Embed import DataEmbedding
# from layers.Short_encoder import Short_encoder # 不再直接使用
from layers.RevIN import RevIN
from layers.MTST_MOE_Encoder import MoELayerBranch
#from layers.Long_encoder import S_Mamba_Encoder # Mamba 专家
# 导入标准 Transformer 组件
from torch.nn import TransformerEncoder, TransformerEncoderLayer
from layers.MTST_MOE_Encoder import MultiBranchMoEEncoder
# --- FFT 周期检测函数 ---
from einops import rearrange

from layers.decomposition import Decomposition
from layers.wavelet_patch_mixer import ResolutionBranch




class AdaTMModel(nn.Module):
    
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.device = getattr(config, 'device', torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        print(f"AdaTMModel_WaveletMultiBranch (Independent Patching, Fixed TypeError) Init: device={self.device}")

        
        self.revin = RevIN(config.c_out, eps=1e-5, affine=config.affine).to(self.device) if config.revin else None
        print(f"  - RevIN Enabled: {config.revin}")

        self.decomposition = Decomposition(
            input_length=config.seq_len, pred_length=config.pred_len,
            wavelet_name=getattr(config, 'wavelet', 'db4'), level=getattr(config, 'level', 1),
            batch_size=config.batch_size, channel=config.enc_in, d_model=config.d_model,
            device=self.device, no_decomposition=getattr(config, 'no_decomposition', False),
            use_amp=config.use_amp
        ).to(self.device)

        self.input_w_dim = self.decomposition.input_w_dim
        self.num_wavelet_coeffs = len(self.input_w_dim)
        print(f"  - Wavelet Decomposed Input Dims: {self.input_w_dim}")
        expected_num_branches = getattr(config, 'level', 1) + 1
        if self.num_wavelet_coeffs != expected_num_branches:
             print(f"警告：计算的小波系数数量 ({self.num_wavelet_coeffs}) 与预期分支数 ({expected_num_branches}) 不符。")

       
        try:
            self.patch_len_list = [int(p) for p in config.patch_len_ls.split(',')]
            self.stride_list = [int(s) for s in config.stride_ls.split(',')]
            if len(self.patch_len_list) != self.num_wavelet_coeffs: raise ValueError(f"patch_len_ls 长度错误")
            if len(self.stride_list) != self.num_wavelet_coeffs: raise ValueError(f"stride_ls 长度错误")
            print(f"  - Branch Patch Lens: {self.patch_len_list}")
            print(f"  - Branch Strides: {self.stride_list}")
        except Exception as e:
             print(f"错误：解析 patch_len_ls 或 stride_ls 参数失败: {e}")
             raise e

        self.d_model = config.d_model
        self.dropout_val = getattr(config, 'dropout', 0.1)

        # --- 创建多分支处理模块 ---
        self.level_branches = nn.ModuleList()
        total_output_dim_from_branches = 0
        self.branch_patch_nums = [] # 存储每个分支的 patch 数量

        for i in range(self.num_wavelet_coeffs):
            coeff_len = self.input_w_dim[i]
            current_patch_len = self.patch_len_list[i]
            current_stride = self.stride_list[i]

            if current_patch_len <= 0 or current_stride <= 0:
                print(f"警告: 分支 {i} patch_len/stride 无效。跳过。")
                self.level_branches.append(None)
                self.branch_patch_nums.append(0) # 记录 patch 数为 0
                continue

            current_patch_num = int((coeff_len - current_patch_len) / current_stride + 1)
            self.branch_patch_nums.append(max(0, current_patch_num)) # 存储计算得到的 patch 数

            if current_patch_num <= 0:
                 print(f"警告: 第 {i} 级小波系数无法分块。跳过。")
                 self.level_branches.append(None)
                 continue

            # --- **修正 ModuleDict：只存储 Module** ---
            branch_modules = nn.ModuleDict({
                # 只存储 nn.Module 子类
                'patch_embed': nn.Linear(current_patch_len, self.d_model).to(self.device),
                'pos_embed': PositionalEmbedding(d_model=self.d_model, max_len=current_patch_num).to(self.device),
                'moe_stack': nn.ModuleList(),
                'norms1': nn.ModuleList(),
            })
            # -----------------------------------------

            # 添加 MoE 层
            num_moe_layers_per_branch = config.e_layers
            for _ in range(num_moe_layers_per_branch):
                 branch_modules['moe_stack'].append(MoELayerBranch(self.config, device=self.device))
                 branch_modules['norms1'].append(nn.LayerNorm(self.d_model).to(self.device))

            self.level_branches.append(branch_modules)
            print(f"  - Created Branch {i} for coeff_len={coeff_len}, patch_len={current_patch_len}, stride={current_stride}, patch_num={current_patch_num}")

            # 累加特征维度
            total_output_dim_from_branches += current_patch_num * self.d_model

        if total_output_dim_from_branches == 0:
            raise ValueError("无法从任何小波系数级别创建有效的分支。")

        print(f"  - Total Flattened Dim from Branches for Head: {total_output_dim_from_branches}")

        # --- 初始化预测头 (保持不变) ---
        self.head = Flatten_Head(
            individual=config.individual, n_vars=config.c_out,
            nf=total_output_dim_from_branches, target_window=config.pred_len,
            head_dropout=getattr(config, 'head_dropout', 0.0)
        ).to(self.device)
        print(f"  - Using Flatten_Head adapted for combined branch outputs.")

        self.dropout = nn.Dropout(self.dropout_val)


    def forward(self, x, x_mark=None):
        B, L, N = x.shape

        # 1. RevIN Norm (Optional) - (保持不变)
        if self.revin: x_norm = self.revin(x, 'norm')
        else: x_norm = x

        # 2. Permute - (保持不变)
        x_permuted = x_norm.permute(0, 2, 1) # [B, N, L]

        # 3. Wavelet Decomposition - (保持不变)
        try: xA, xD = self.decomposition.transform(x_permuted)
        except Exception as e: print(f"Error during wavelet decomposition: {e}"); raise e
        all_coeffs = [xA] + xD

        # 4. Process each level with its dedicated branch
        branch_feature_outputs = []
        for i in range(self.num_wavelet_coeffs):
            branch = self.level_branches[i]
            if branch is None: continue

            coeffs = all_coeffs[i]
            coeff_len = coeffs.shape[-1]

            # --- Branch Processing ---
            try:
                # **修正：从 self 属性列表或模块属性获取参数**
                current_patch_len = self.patch_len_list[i] # 从列表获取
                current_stride = self.stride_list[i]     # 从列表获取
                current_patch_num = self.branch_patch_nums[i] # 从初始化时存储的列表获取

                # 4.2 Patching (使用获取到的参数)
                required_len_for_patching = (current_patch_num - 1) * current_stride + current_patch_len
                padding_needed = max(0, required_len_for_patching - coeff_len)

                if padding_needed > 0: coeffs_padded = F.pad(coeffs, (0, padding_needed), mode='replicate')
                elif coeff_len > required_len_for_patching: coeffs_padded = coeffs[:, :, :required_len_for_patching]
                else: coeffs_padded = coeffs

                patches = coeffs_padded.unfold(dimension=-1, size=current_patch_len, step=current_stride)

                if patches.shape[2] != current_patch_num:
                     print(f"警告: Forward branch {i} patch 数 ({patches.shape[2]}) != 预期 ({current_patch_num})。调整。")
                     patches = patches[:, :, :current_patch_num, :]

                # 4.3 Embedding (使用 branch 中的模块)
                embedded_patches = branch['patch_embed'](patches) # [B, N, P_i, D]

                # 4.4 Reshape & Positional Encoding (使用 branch 中的模块)
                u_branch = rearrange(embedded_patches, 'b n p d -> (b n) p d')
                u_branch = self.dropout(u_branch)
                pos_emb_val = branch['pos_embed'](u_branch)
                # 添加 PE
                if pos_emb_val.shape[0] == 1: u_branch = u_branch + pos_emb_val
                elif pos_emb_val.dim() == 2: u_branch = u_branch + pos_emb_val.unsqueeze(0)
                else: print(f"警告: 分支 {i} PosEmb 形状 {pos_emb_val.shape} 无法应用")

                # 4.5 Apply MoE Stack (使用 branch 中的模块)
                for norm_layer, moe_layer in zip(branch['norms1'], branch['moe_stack']):
                     res = u_branch
                     u_norm = norm_layer(u_branch)
                     moe_out = moe_layer(u_norm)
                     u_branch = res + self.dropout(moe_out)

                # 4.6 准备拼接输出 (保持不变)
                branch_output_flat = rearrange(u_branch, '(b n) p d -> b n (p d)', b=B)
                branch_feature_outputs.append(branch_output_flat)

            except Exception as e:
                print(f"Error processing branch {i} (patch_len={current_patch_len}, stride={current_stride}): {e}")
                raise e

        # 5. Combine Branch Outputs (保持不变)
        if not branch_feature_outputs: raise ValueError("没有生成任何有效的分支输出！")
        combined_features = torch.cat(branch_feature_outputs, dim=-1)

        # 6. Final Prediction Head (保持不变)
        try: dec_out = self.head(combined_features)
        except Exception as e:
             print(f"Error during prediction head: {e}")
             expected_nf = self.head.linear.in_features if not self.head.individual else 'individual'
             print(f"Input shape to head: {combined_features.shape}, Expected head input features (nf): {expected_nf}")
             raise e

        # 7. Permute back & Denorm (保持不变)
        dec_out = dec_out.permute(0, 2, 1)
        if self.revin: dec_out = self.revin(dec_out, 'denorm')

        # 8. Clamp & Return (保持不变)
        dec_out = torch.clamp(dec_out, min=-1e4, max=1e4)
        return dec_out[:, :, :self.config.c_out]