from data_provider.data_factory import data_provider
from exp.exp_basic import Exp_Basic
from models import AdaTM
from utils.tools import EarlyStopping, adjust_learning_rate, visual, test_params_flop
from utils.metrics import metric

import numpy as np
import torch
import torch.nn as nn
from torch import optim
from torch.optim import lr_scheduler 
from torch.cuda.amp import autocast, GradScaler
import os
import time

import warnings
import matplotlib.pyplot as plt
import numpy as np
from models.AdaTM import AdaTMModel
warnings.filterwarnings('ignore')

class Exp_Main(Exp_Basic):
    def __init__(self, args):
        super(Exp_Main, self).__init__(args)
        self.args.device = self.device  # 将设备信息传递到config

    def _build_model(self):
        model_dict = {
            'AdaTM': AdaTMModel,
        }
        model = model_dict[self.args.model](self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)

        # 将 NumPy 数组转换为 Tensor
        data_x = torch.from_numpy(data_set.data_x).float()
        data_y = torch.from_numpy(data_set.data_y).float()

        # 检查输入数据和标签数据的完整性
        def calculate_stats(tensor):
            # 过滤 NaN 值
            tensor_filtered = tensor[~torch.isnan(tensor)]
            mean = torch.mean(tensor_filtered).item() if tensor_filtered.numel() > 0 else 0.0
            std = torch.std(tensor_filtered).item() if tensor_filtered.numel() > 0 else 0.0
            return mean, std

        # 输入数据统计
        mean_x, std_x = calculate_stats(data_x)
        #print(f"[数据检查] {flag} 输入数据统计 - 均值: {mean_x:.4f}, 方差: {std_x:.4f}")

        # 标签数据统计
        mean_y, std_y = calculate_stats(data_y)
        #print(f"[数据检查] {flag} 标签数据统计 - 均值: {mean_y:.4f}, 方差: {std_y:.4f}")

        # 断言确保数据无异常
        assert not torch.isnan(data_x).any(), f"{flag} 输入数据包含 NaN!"
        assert not torch.isinf(data_x).any(), f"{flag} 输入数据包含 Inf!"
        assert not torch.isnan(data_y).any(), f"{flag} 标签数据包含 NaN!"
        assert not torch.isinf(data_y).any(), f"{flag} 标签数据包含 Inf!"

        return data_set, data_loader

    def _select_optimizer(self):
        model_optim = optim.Adam(self.model.parameters(), lr=self.args.learning_rate)
        return model_optim

    def train(self, setting):
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        test_data, test_loader = self._get_data(flag='test')

        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        time_now = time.time()

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()

        # 仅在使用 AMP 时初始化 GradScaler
        scaler = torch.cuda.amp.GradScaler() if self.args.use_amp else None

        # 调度器 (保持不变)
        scheduler = lr_scheduler.OneCycleLR(optimizer = model_optim,
                                            steps_per_epoch = train_steps,
                                            pct_start = self.args.pct_start,
                                            epochs = self.args.train_epochs,
                                            max_lr = self.args.learning_rate)

        max_grad_norm = 1.0  # 初始裁剪阈值

        for epoch in range(self.args.train_epochs):
            iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()
            # print(f"\n--- 开始轮次 {epoch+1} ---") # 添加轮次标记

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                model_optim.zero_grad() # 在迭代开始时清零梯度
                # 动态调整梯度裁剪阈值
                if i % 10 == 0 and epoch == 0:
                    max_grad_norm = max(0.5, max_grad_norm * 0.9)  # 逐步收紧
                # --- 数据准备 ---
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                # batch_x_mark = batch_x_mark.float().to(self.device) # 仅当模型/损失需要时
                # batch_y_mark = batch_y_mark.float().to(self.device) # 仅当模型/损失需要时

                # --- 数据健全性检查 (NaN 调试的关键) ---
                if torch.isnan(batch_x).any() or torch.isinf(batch_x).any():
                    print(f"❌ 在轮次 {epoch+1}，迭代 {i} 的 batch_x 中检测到 NaN/Inf。跳过此批次。")
                    continue # 跳过这个批次
                if torch.isnan(batch_y).any() or torch.isinf(batch_y).any():
                    print(f"❌ 在轮次 {epoch+1}，迭代 {i} 的 batch_y 中检测到 NaN/Inf。跳过此批次。")
                    continue # 跳过这个批次

                # --- 目标准备 ---
                
                # 确保 batch_y 具有正确的长度 (pred_len) 以便直接比较
                # 如果 batch_y 包含 label_len + pred_len，则对其进行切片：
                # batch_y_target = batch_y[:, -self.args.pred_len:, :]
                # 如果 batch_y *仅* 包含 pred_len (如断言所示)，则直接使用：
                if batch_y.shape[1] != self.args.pred_len:
                     # 这种情况取决于你的 DataLoader 如何构造 batch_y
                     # 假设它包含 label_len + pred_len:
                     print(f"警告：batch_y 形状 {batch_y.shape} != pred_len {self.args.pred_len}。正在切片目标。")
                     batch_y_target = batch_y[:, -self.args.pred_len:, :].to(self.device)
                     if batch_y_target.shape[1] != self.args.pred_len:
                          raise ValueError(f"无法将 batch_y 切片到 pred_len {self.args.pred_len}")
                else:
                    batch_y_target = batch_y.to(self.device) # 已经是正确的形状

                # --- 前向传播、损失计算、反向传播、优化器步骤 ---
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        
                        outputs = self.model(batch_x, batch_x_mark) # <--- 修改点

                        # --- 输出健全性检查 ---
                        if torch.isnan(outputs).any() or torch.isinf(outputs).any():
                           print(f"❌ 在轮次 {epoch+1}，迭代 {i} 的模型输出中检测到 NaN/Inf")
                           # 可选：在此处添加更多调试信息，例如打印输入统计信息
                           # print(f"   输入 batch_x 统计: min={batch_x.min()}, max={batch_x.max()}, mean={batch_x.mean()}")
                           raise RuntimeError(f"在 E{epoch+1}, I{i} 的模型输出中出现 NaN/Inf")

                        # 确保形状匹配以计算损失
                        if outputs.shape != batch_y_target.shape:
                             raise ValueError(f"形状不匹配！输出: {outputs.shape}, 目标: {batch_y_target.shape} at E{epoch+1}, I{i}")

                        loss = criterion(outputs, batch_y_target)

                        # --- 损失健全性检查 ---
                        if torch.isnan(loss).any() or torch.isinf(loss).any():
                           print(f"❌ 在轮次 {epoch+1}，迭代 {i} 的损失中检测到 NaN/Inf")
                           # 可选：打印输出/目标统计信息
                           # print(f"   输出统计: min={outputs.min()}, max={outputs.max()}, mean={outputs.mean()}")
                           # print(f"   目标统计: min={batch_y_target.min()}, max={batch_y_target.max()}, mean={batch_y_target.mean()}")
                           raise RuntimeError(f"在 E{epoch+1}, I{i} 的损失值中出现 NaN/Inf")

                           # 梯度裁剪
                    scaler.scale(loss).backward()


                    # --- 梯度健全性检查 (可选但推荐) ---
                    # for name, param in self.model.named_parameters():
                    #     if param.grad is not None:
                    #         if torch.isnan(param.grad).any() or torch.isinf(param.grad).any():
                    #             print(f"⚠️ 在 {name} 中出现 NaN/Inf 梯度 @ E{epoch+1}, I{i}")
                    #             # 考虑停止或跳过优化器步骤
                    #             # raise RuntimeError(f"在 {name} 中出现 NaN/Inf 梯度")

                    # AMP 优化器步骤
                    scaler.unscale_(model_optim) # 在裁剪前取消缩放
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.1) # 梯度裁剪
                    scaler.step(model_optim)
                    scaler.update()

                else: # 不使用 AMP
                    # 模型前向传播
                    outputs = self.model(batch_x, batch_x_mark) # <--- 修改点

                    # --- 输出健全性检查 ---




                    if torch.isnan(outputs).any() or torch.isinf(outputs).any():
                        print(f"❌ 在模型输出（未使用 AMP）中检测到 NaN/Inf，位于轮次 {epoch+1}，迭代 {i}")
                        raise RuntimeError(f"在模型输出（未使用 AMP）中出现 NaN/Inf，位于 E{epoch+1}, I{i}")

                    # 确保形状匹配以计算损失
                    if outputs.shape != batch_y_target.shape:
                         raise ValueError(f"形状不匹配！输出: {outputs.shape}, 目标: {batch_y_target.shape} at E{epoch+1}, I{i}")

                    loss = criterion(outputs, batch_y_target)

                    # --- 损失健全性检查 ---
                    if torch.isnan(loss).any() or torch.isinf(loss).any():
                       print(f"❌ 在损失（未使用 AMP）中检测到 NaN/Inf，位于轮次 {epoch+1}，迭代 {i}")
                       raise RuntimeError(f"在损失值（未使用 AMP）中出现 NaN/Inf，位于 E{epoch+1}, I{i}")

                    # 标准反向传播
                    loss.backward()

                    # --- 梯度健全性检查 (可选但推荐) ---
                    # for name, param in self.model.named_parameters():
                    #     if param.grad is not None:
                    #         if torch.isnan(param.grad).any() or torch.isinf(param.grad).any():
                    #             print(f"⚠️ 在 {name} 中出现 NaN/Inf 梯度（未使用 AMP） @ E{epoch+1}, I{i}")
                    #             # raise RuntimeError(f"在 {name} 中出现 NaN/Inf 梯度")

                    # 标准优化器步骤
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0) # 梯度裁剪
                    model_optim.step()

                train_loss.append(loss.item())

                # --- 日志记录与计时 ---
                if (i + 1) % 100 == 0: # 每 100 次迭代打印一次
                    current_lr = model_optim.param_groups[0]['lr']
                    print(f"轮次: {epoch + 1}, 迭代: {i + 1}/{train_steps} | 损失: {loss.item():.7f} | 学习率: {current_lr:.6f}")
                    speed = (time.time() - time_now) / iter_count
                    left_time = speed * ((self.args.train_epochs - epoch) * train_steps - (i + 1))
                    print(f"  速度: {speed:.4f} 秒/迭代; 剩余时间: {left_time:.4f} 秒")
                    iter_count = 0 # 重置计数器以计算速度
                    time_now = time.time()

                # --- 调度器步骤 ---
                # OneCycleLR 在每次迭代后步进
                if scheduler is not None:
                     scheduler.step()
                     # 计算训练损失的平均值
            train_loss_avg = np.mean(train_loss) if train_loss else float('nan')

            # --- 轮次结束 ---
            print("轮次: {} 耗时: {}".format(epoch + 1, time.time() - epoch_time))
            vali_loss = self.vali(vali_data, vali_loader, criterion)
            test_loss = self.vali(test_data, test_loader, criterion)  # 通常在训练后才计算测试损失

            print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f} Test Loss: {4:.7f}".format(
                    epoch + 1, train_steps, train_loss_avg, vali_loss, test_loss))

            early_stopping(vali_loss, self.model, path)
            if early_stopping.early_stop:
                print("早停")
                break

            # 调整学习率 (如果未使用 OneCycleLR，则根据 'lradj' 类型调整逻辑)
            # if self.args.lradj != 'TST' and scheduler is None: # 其他调度器的示例
            #     adjust_learning_rate(model_optim, None, epoch + 1, self.args) # 如果 adjust_learning_rate 需要，传递 scheduler
            # elif self.args.lradj == 'TST':
            #     # 如果使用 OneCycleLR（每次迭代都步进），这似乎是多余的
            #     print('将学习率更新为 {}'.format(scheduler.get_last_lr()[0]))
            #     pass # 已经步进

        # --- 训练后 ---
        best_model_path = path + '/' + 'checkpoint.pth'
        # 加载前确保最佳模型已保存
        if os.path.exists(best_model_path):
             self.model.load_state_dict(torch.load(best_model_path))
        else:
             print(f"警告: 检查点路径 {best_model_path} 未找到。使用最后一个模型状态。")

        # 计算最终测试损失
        print("\n--- 计算最终测试损失 ---")
        test_loss_final = self.vali(test_data, test_loader, criterion)
        print(f"最终测试损失: {test_loss_final:.7f}")

        return self.model

    def vali(self, vali_data, vali_loader, criterion):
        total_loss = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float() # 初始保留在 CPU 上，以便切片

                # 准备目标
                if batch_y.shape[1] != self.args.pred_len:
                     batch_y_target = batch_y[:, -self.args.pred_len:, :].to(self.device)
                     if batch_y_target.shape[1] != self.args.pred_len:
                           raise ValueError(f"[验证] 无法将 batch_y 切片到 pred_len {self.args.pred_len}")
                else:
                     batch_y_target = batch_y.to(self.device)

                # 前向传播
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        outputs = self.model(batch_x, batch_x_mark) # <--- 修改点
                else:
                    outputs = self.model(batch_x, batch_x_mark) # <--- 修改点
                # 检查验证输出中的 NaN/Inf
                if torch.isnan(outputs).any() or torch.isinf(outputs).any():
                   print(f"❌ 在验证输出中检测到 NaN/Inf，位于迭代 {i}。将损失设为 NaN。")
                   total_loss.append(float('nan'))
                   continue # 跳过此批次的损失计算

                # 确保形状匹配
                if outputs.shape != batch_y_target.shape:
                     print(f"[验证] 形状不匹配！输出: {outputs.shape}, 目标: {batch_y_target.shape} at I{i}")
                     total_loss.append(float('nan')) # 或进行其他处理
                     continue

                # 使用正确设备上的目标计算损失
                pred = outputs.detach() # 已在设备上
                true = batch_y_target.detach() # 已在设备上
                loss = criterion(pred, true)

                # 检查损失
                if torch.isnan(loss).any() or torch.isinf(loss).any():
                    print(f"❌ 在验证损失中检测到 NaN/Inf，位于迭代 {i}。追加 NaN。")
                    total_loss.append(float('nan'))
                else:
                    total_loss.append(loss.item()) # 使用 item()

        # 计算平均损失，忽略 NaN
        valid_losses = [l for l in total_loss if not np.isnan(l)]
        avg_loss = np.average(valid_losses) if valid_losses else float('nan')

        self.model.train() # 设置回训练模式
        return avg_loss

    # --- 测试函数更新 ---
    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='test')

        if test:
            print('加载模型')
            model_path = os.path.join('./checkpoints/' + setting, 'checkpoint.pth')
            if not os.path.exists(model_path):
                 print(f"错误: 在 {model_path} 未找到模型检查点")
                 return
            self.model.load_state_dict(torch.load(model_path, map_location=self.device))

        preds = []
        trues = []
        # inputx = [] # 如果需要则保留
        folder_path = './test_results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float() # 初始保留在 CPU 上

                # 准备目标
                if batch_y.shape[1] != self.args.pred_len:
                     # 保留为 numpy 以便后续计算指标
                     batch_y_target = batch_y[:, -self.args.pred_len:, :].numpy()
                     if batch_y_target.shape[1] != self.args.pred_len:
                           raise ValueError(f"[测试] 无法将 batch_y 切片到 pred_len {self.args.pred_len}")
                else:
                     batch_y_target = batch_y.numpy()

                # 前向传播
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                       outputs = self.model(batch_x, batch_x_mark) # <--- 修改点
                else:
                    outputs = self.model(batch_x, batch_x_mark) # <--- 修改点

                # 检查 NaN/Inf
                if torch.isnan(outputs).any() or torch.isinf(outputs).any():
                   print(f"❌ 在测试输出中检测到 NaN/Inf，位于迭代 {i}。跳过此批次的指标计算。")
                   continue

                # 分离并移动到 CPU 以便存储/计算指标
                pred = outputs.detach().cpu().numpy()
                true = batch_y_target # 已经是 numpy

                # 在追加之前确保形状匹配
                if pred.shape != true.shape:
                     print(f"[测试] 形状不匹配！预测: {pred.shape}, 真实: {true.shape} at I{i}")
                     continue

                preds.append(pred)
                trues.append(true)
                # inputx.append(batch_x.detach().cpu().numpy())
                # --- 关键改动：在这里添加新的绘图逻辑 ---
                if i == 0:
                    # 准备绘图数据
                    input_seq = batch_x[0, :, 0].detach().cpu().numpy()  # 历史输入
                    true_future = true[0, :, 0]  # 真实的未来
                    pred_future = pred[0, :, 0]  # 预测的未来

                    # 历史部分的时间轴
                    history_time_axis = np.arange(len(input_seq))
                    # 预测部分的时间轴
                    prediction_time_axis = np.arange(len(input_seq), len(input_seq) + len(true_future))

                    # --- 开始绘图 ---
                    plt.figure(figsize=(6, 5))  # 调整 figsize 以匹配您想要的图片比例

                    # 绘制历史+真实未来 (一条完整的蓝线)
                    full_true_series = np.concatenate((input_seq, true_future))
                    plt.plot(np.arange(len(full_true_series)), full_true_series, label='GroundTruth',
                             color='C0')  # 使用默认颜色 C0 (蓝色系)

                    # 绘制历史+预测未来 (一条完整的橙线)
                    full_pred_series = np.concatenate((input_seq, pred_future))
                    plt.plot(np.arange(len(full_pred_series)), full_pred_series, label='Prediction',
                             color='C1')  # 使用默认颜色 C1 (橙色系)

                    # 添加图表元素 (简化版本)

                    plt.title('ETTh1', fontsize=16)
                    plt.ylabel('Input-672-predict-96', fontsize=16)
                    plt.legend()
                    # 调整图例字体大小
                    plt.legend(fontsize=14)
                    # 增大坐标轴刻度字体
                    plt.tick_params(axis='both', which='major', labelsize=14)
                    plt.grid(True, linestyle=':', alpha=0.6)

                    # 保存图片
                    fig_save_path = os.path.join(folder_path, f'prediction_style_2_batch_{i}.png')
                    plt.savefig(fig_save_path, dpi=300)
                    print(f"新风格的预测可视化图已保存至: {fig_save_path}")
                    plt.close()  # 关闭图像，防止在内存中积累
                # 可视化 (可选)
                # if i % 20 == 0:
                #    input_vis = batch_x.detach().cpu().numpy()
                #    # 确保证可视化索引有效
                #    if input_vis.shape[0] > 0 and true.shape[0] > 0 and pred.shape[0] > 0:
                #         # 假设最后一个特征是要可视化的特征
                #         f_dim_vis = -1
                #         seq_len_vis = input_vis.shape[1]
                #         gt = np.concatenate((input_vis[0, :seq_len_vis, f_dim_vis], true[0, :, f_dim_vis]), axis=0)
                #         pd = np.concatenate((input_vis[0, :seq_len_vis, f_dim_vis], pred[0, :, f_dim_vis]), axis=0)
                #         visual(gt, pd, os.path.join(folder_path, str(i) + '.pdf'))

        # 检查是否收集到任何结果
        if not preds:
             print("测试期间未收集到有效预测。无法计算指标。")
             return

        # --- 指标计算 ---
        preds = np.array(preds)
        trues = np.array(trues)

        # 重塑：这里要小心。确保这与批次处理方式一致。
        # 如果由于 NaN 导致批次被丢弃，这可能会出错或给出错误结果。
        # 更安全的方法是按批次计算指标并取平均值，或小心处理重塑。
        # 假设所有批次大小相同（例如，loader 中 drop_last=True）：
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])

        # 检查聚合数组中的 NaN
        if np.isnan(preds).any() or np.isinf(preds).any():
             print("警告: 在聚合预测数组中发现 NaN/Inf。")
             preds = np.nan_to_num(preds) # 替换 NaN 以计算指标
        if np.isnan(trues).any() or np.isinf(trues).any():
             print("警告: 在聚合真实值数组中发现 NaN/Inf。")
             trues = np.nan_to_num(trues)

        mae, mse, rmse, mape, mspe, rse, corr = metric(preds, trues)

        print('mse:{}, mae:{}, rse:{}'.format(mse, mae, rse))
        f = open("result.txt", 'a')
        f.write(setting + "  \n")
        f.write('mse:{}, mae:{}, rse:{}'.format(mse, mae, rse))
        f.write('\n')
        f.write('\n')
        f.close()

        # 保存结果
        results_folder_path = './results/' + setting + '/' # 最终结果使用不同文件夹
        if not os.path.exists(results_folder_path):
            os.makedirs(results_folder_path)


        np.save(results_folder_path + 'metrics.npy', np.array([mae, mse, rmse, mape, mspe, rse]))
        np.save(results_folder_path + 'pred.npy', preds)
        np.save(results_folder_path + 'true.npy', trues)

        # 将结果保存到文本文件
        try:
             # 使用不同的文件名存储所有指标
             with open("result_all_metrics.txt", 'a') as f:
                f.write(setting + "  \n")
                f.write('MAE:{:.4f}, MSE:{:.4f}, RMSE:{:.4f}, MAPE:{:.4f}, MSPE:{:.4f}, RSE:{:.4f}'.format(mae, mse, rmse, mape, mspe, rse))
                f.write('\n')
                f.write('\n')
        except Exception as e:
             print(f"写入结果文件时出错: {e}")

        return

    def _select_criterion(self):
        # 保留 SafeMSELoss，这是一个很好的预防措施
        class SafeMSELoss(nn.MSELoss):
            def forward(self, input, target):
                # 限制值以防止极端损失计算导致 NaN
                # 根据归一化/RevIN 后预期的数据范围调整限制范围
                input_c = torch.clamp(input, min=-1e4, max=1e4)
                target_c = torch.clamp(target, min=-1e4, max=1e4)
                # 检查是否应用了限制 (可选调试)
                # if not torch.equal(input_c, input) or not torch.equal(target_c, target):
                #     print("警告: 在 SafeMSELoss 中应用了值限制")
                return super().forward(input_c, target_c)

        return SafeMSELoss()

    def predict(self, setting, load=False):
        pred_data, pred_loader = self._get_data(flag='pred')

        if load:
            path = os.path.join(self.args.checkpoints, setting)
            best_model_path = path + '/' + 'checkpoint.pth'
            self.model.load_state_dict(torch.load(best_model_path))

        preds = []
        trues = []

        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(pred_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # long short input
                long, short, long_mark, short_mark = batch_x, batch_y[:, :self.args.label_len, :], batch_x_mark, batch_y_mark[:, :self.args.label_len, :]

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # dec_inp = torch.zeros([batch_y.shape[0], self.args.pred_len, batch_y.shape[2]]).float().to(batch_y.device)
                # dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.model == 'AdaTM':
                            outputs = self.model(long)
                        elif 'Linear' in self.args.model or 'TST' in self.args.model:
                            outputs = self.model(batch_x)
                        else:
                            if self.args.output_attention:
                                outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                            else:
                                outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                else:
                    if self.args.model == 'AdaTM':
                        outputs = self.model(long)
                    if 'Linear' in self.args.model or 'TST' in self.args.model:
                        outputs = self.model(batch_x)
                    else:
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                outputs = outputs.detach().cpu().numpy()
                batch_y = batch_y.detach().cpu().numpy()
                
                pred = outputs
                true = batch_y

                preds.append(pred)
                trues.append(true)

        preds = np.array(preds)
        trues = np.array(trues)

        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        
        # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        np.save(folder_path + 'real_pred.npy', preds)
        np.save(folder_path + 'real_true.npy', trues)

        return
